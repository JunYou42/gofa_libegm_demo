// test.cpp

#include<iostream>
#include <abb_libegm/egm_trajectory_interface.h>

using namespace std;

int main(void){
    cout<< "hello World" << endl;
    return(0);
}